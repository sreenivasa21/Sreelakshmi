ALTER TABLE customers
ADD otp VARCHAR(6),
ADD otp_expiry DATETIME;
