exports.sendWhatsApp = async (mobile, msg) => {
  console.log("WhatsApp →", mobile, msg);
};
